export const PAYMENT_ADDR = 'addr_test1qrw4u8zarjqsgadhhw03f709ef8tlpqznpx06ncpzs9pgv0pvp3qyw2z2pd36665c3xw6ype5t8smyusr38msvawq04qq0u92h';
    export const BLOCKFROST_PROJ = 'testneteDgsi4q4d7ZvI0StUUUT6UK5DazZeyQw';
    export const MINT_PRICE = '1000000';
    export const MINT_REBATE = '0';
    export const LOWER_LIMIT = '1';
    export const UPPER_LIMIT = '1';
	export const REQUIRED_POLICY_KEY = '';
    export const REQUIRED_POLICY_MIN = 0;
