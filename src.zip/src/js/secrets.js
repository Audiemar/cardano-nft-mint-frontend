export const PAYMENT_ADDR = 'addr1qxx3nzhwqczartkuh7xymf7r2xrys4pt5x2mn0ryj79357y7y6ll6a8g5pp4xq6hjzngdcwgfct46ephuca2qw3z4yvq0sqxcg';
    export const BLOCKFROST_PROJ = 'WalletNotes';
    export const MINT_PRICE = '6000000';
    export const MINT_REBATE = '1';
    export const LOWER_LIMIT = '1';
    export const UPPER_LIMIT = '1';
	export const REQUIRED_POLICY_KEY = '';
    export const REQUIRED_POLICY_MIN = 0;