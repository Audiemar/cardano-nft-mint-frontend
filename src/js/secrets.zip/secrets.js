export const PAYMENT_ADDR = '';
export const BLOCKFROST_PROJ = '';
export const MINT_PRICE = '';
export const LOWER_LIMIT = '';
export const UPPER_LIMIT = '';
export const REQUIRED_POLICY_KEY = '';
export const REQUIRED_POLICY_MIN = 0;